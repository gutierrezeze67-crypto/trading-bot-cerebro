"""
╔══════════════════════════════════════════════════════════╗
║  TRADING PLATFORM - CONFIGURACIÓN CENTRAL               ║
║  Cambia SOLO las claves API en la sección marcada       ║
╚══════════════════════════════════════════════════════════╝
"""

# ══════════════════════════════════════════════════════════
# 🔑 SECCIÓN DE CLAVES API - PON TUS DATOS REALES AQUÍ
# ══════════════════════════════════════════════════════════

# Gemini AI (Google AI Studio)
# Verificada contra el panel de aistudio.google.com/apikey el 10/07/2026: las claves
# nuevas de AI Studio ahora empiezan con "AQ." (antes empezaban con "AIzaSy...").
GEMINI_API_KEY = "AQ.Ab8RN6IvCjGyjGtqLvEJo4cz0Oo7HUODv4LzPW7a48CVqnb6fw"

# Telegram (para recibir alertas en tu móvil)
TELEGRAM_BOT_TOKEN = "8778286269:AAERgXYISi-FV_Pqiw3FlO3Do8J1gHKx7qE"
TELEGRAM_CHAT_ID = "2023972712"

# Discord Bot (mismo bot para los dos canales - mismo ID de aplicación,
# token rotado el 13/07/2026)
DISCORD_BOT_TOKEN = "MTUyNDkxMTM2MDM1MjE5NDcyMQ.GG6t-q.SfiHTE4aahOftyM-Lxn0T4jBP_5ejoyYGqe6cY"

# Discord Webhook (para ENVIAR notificaciones de alertas)
DISCORD_WEBHOOK_URL = "https://discord.com/api/webhooks/PON_TU_WEBHOOK_AQUI"

# Canal de Discord donde están las imágenes de Trading Different (zonas por captura + Gemini Vision)
DISCORD_ZONAS_CHANNEL_ID = 1525123845550247986

# Canal de Discord "Latin trading 5.0" (zonas de liquidez en texto, para el detector LIQUIDITY_POOL)
DISCORD_LIQUIDITY_CHANNEL_ID = 1479115608321949826
DISCORD_LIQUIDITY_SYMBOL_FILTER = "BTCUSD"

# ══════════════════════════════════════════════════════════
# 📊 SÍMBOLOS DE TRADING (los que quieres monitorear)
# ══════════════════════════════════════════════════════════
SYMBOLS = [
    "BTCUSDT",   # Bitcoin
    "XAUUSDT",   # Oro (Gold)
    "XAGUSDT",   # Plata (Silver)
    "USOIL",     # Petróleo WTI
    "US30",      # Dow Jones
    "SP500",     # S&P 500
    "NAS100",    # Nasdaq 100
]

# ══════════════════════════════════════════════════════════
# ⚙️ CONFIGURACIÓN GENERAL
# ══════════════════════════════════════════════════════════
PRIMARY_TF = "15m"
DAILY_LOSS_LIMIT_PERCENT = 5.0
MAX_POSITIONS = 3

# ══════════════════════════════════════════════════════════
# 🔍 CONFIGURACIÓN DEL SCANNER SENSEI V3
# ══════════════════════════════════════════════════════════
SCANNER_CONFIG = {
    "hh_ll_period": 70,
    "bos_lookback": 20,
    "pivot_len": 3,
    "cont_alta_th": 50.0,
    "cont_baja_th": 55.0,
    "choch_window": 20,
    "min_prob_ob": 50,
    "max_ob_activos": 8,
    "max_fvg_activos": 10,
    "historical_zones": 90,
    "min_risk_atr": 0.5,
    "require_disp": False,
    "disp_multiplier": 1.2,
    "atr_length": 14,
    "w1": 0.35,
    "w2": 0.25,
    "w3": 0.25,
    "w4": 0.15,
}

# ══════════════════════════════════════════════════════════
# 🤖 CONFIGURACIÓN GEMINI 2.5 FLASH
# ══════════════════════════════════════════════════════════
GEMINI_MODES = {
    "monitoreo": {
        "temperature": 0.3,
        "max_tokens": 500,
        "system_prompt": "Eres un monitor de trading. Analiza brevemente. Sé conciso."
    },
    "mentoria": {
        "temperature": 0.6,
        "max_tokens": 1000,
        "system_prompt": "Eres un mentor de trading experto. Explica y ayuda a mejorar."
    },
    "analisis_profundo": {
        "temperature": 0.4,
        "max_tokens": 2000,
        "system_prompt": "Analista profesional. Análisis técnico detallado con zonas, SVP, fractales."
    }
}
