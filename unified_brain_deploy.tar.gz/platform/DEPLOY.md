# Deploy de unified_brain a un VM

## 0. Antes de nada: ¿tu VM es Windows o Linux?

**El paquete `MetaTrader5` (usado por `unified_brain/src/execution/mt5_direct.py`
y por el terminal que lanza `MCPDispatcher`) SOLO funciona en Windows.** Envuelve
la API nativa del terminal MT5 -- no hay build para Linux/Mac, y correrlo bajo
Wine no está probado en este repo.

- Si tu VM de Google Cloud es **Windows Server**: todo este documento aplica tal cual.
- Si es **Linux** (lo más común en GCE por default): `BRAIN` (el proceso que
  ejecuta órdenes reales) **no va a poder conectarse a MT5 desde ahí**. Opciones
  reales: (a) usar una VM Windows para esto especificamente, o (b) dejar MT5
  corriendo en tu máquina local/una VM Windows aparte y que `unified_brain`
  en el VM Linux le hable por red -- eso es un cambio de arquitectura que no
  está implementado hoy (`mcp_dispatcher.py`/`mt5_direct.py` asumen terminal
  local). Confirmá el SO del VM antes de migrar, para no descubrir esto recién
  en producción.

## 1. Qué hay en este .zip/.tar.gz

```
platform/
  config/                  <- config compartido (constants/settings/assets/broker_config)
  unified_brain/
    .env                   <- credenciales reales (MT5, Binance) -- ver seccion 4
    api.py
    main_orchestrator.py
    requirements.txt       <- dependencias reales, verificadas contra los imports
    config/                <- copia local (systemInstruction.txt, cache de zonas)
    src/
      brain_htf_funding.py, snapshot_engine.py, order_flow_signal.py,
      orderflow_data.py, notifier.py, zone_performance_db.py,
      execution/  (mcp_dispatcher.py, mt5_direct.py)
      experts/    (base_expert.py, scalping_expert.py, swing_expert.py)
      risk/       (risk_engine.py, risk_manager.py)
      router/     (deterministic_router.py)
      schemas/    (market.py, risk.py, signals.py)
      services/   (signal_orchestrator.py)
  ecosystem.config.js      <- config de PM2
```

**Extraé el archivo directamente en `~/platform/`** (no en
`~/platform/unified_brain/`) -- `unified_brain/src/__init__.py` resuelve
`config/` como *hermano* de `unified_brain/` (tres niveles arriba de su propio
archivo), así que la carpeta `config/` de arriba tiene que quedar al lado de
`unified_brain/`, no adentro.

```bash
mkdir -p ~/platform
tar -xzf unified_brain_deploy.tar.gz -C ~/platform --strip-components=1
# deberia quedar ~/platform/config/ y ~/platform/unified_brain/ como hermanos
```

## 2. Instalación

```bash
cd ~/platform/unified_brain
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## 3. Variables de entorno

`unified_brain/.env` ya viene con tus credenciales reales de MT5/Binance --
`main_orchestrator.py` lo carga automáticamente al arrancar (`load_dotenv`).
Revisalo/editalo si cambiás de cuenta o de VM:

```
MT5_LOGIN=...
MT5_PASSWORD=...
MT5_SERVER=...
MT5_TERMINAL_PATH=...     <- default es un path de Windows, ajustalo si corresponde
MT5_DIRECT_EXECUTION=...
UNIFIED_BRAIN_PORT=8001
UNIFIED_BRAIN_SYMBOL=BTCUSDT
UNIFIED_BRAIN_USER_ID=...
```

`config/settings.py` (el que quedó como hermano de `unified_brain/`) trae tus
claves de Gemini/Discord/Telegram hardcodeadas -- necesarias si además corrés
`src.order_flow_signal --deterministic` o `src.cerebro_gemini` standalone (no
las necesita el BRAIN por sí solo).

## 4. Seguridad -- este paquete lleva secretos reales en texto plano

`unified_brain/.env`, `config/settings.py` y `config/firebase-service-account.json`
tienen credenciales reales (MT5, Binance, Gemini, Discord, Telegram, Firebase).
Transferí este archivo por un canal privado (`scp`/`rsync` sobre SSH), nunca por
email, Slack público, un bucket sin permisos, ni lo subas a ningún repo. Borrá
la copia local del .tar.gz/.zip una vez transferido si no la necesitás más.

## 5. Arrancar con PM2

```bash
npm install -g pm2   # si no lo tenés
cd ~/platform
pm2 start ecosystem.config.js
pm2 logs brain        # ver logs en vivo
pm2 save              # persistir entre reinicios del VM
pm2 startup           # generar el comando para auto-arrancar al boot (seguir las instrucciones que imprime)
```

`ecosystem.config.js` solo levanta `BRAIN` (el motor que ejecuta órdenes
reales). Si además querés los otros procesos (SCALP/SWING/zone readers/
dashboard), usá `start_all.py --only ...` del repo completo -- este paquete es
específicamente "el cerebro", no la plataforma entera.

## 6. Primer arranque -- qué esperar

- `BRAIN` necesita ~3.75h de warmup (historial de velas 1m acumulado) antes de
  que el cerebro swing (`atr14_15m`/`vwap_15m`) empiece a evaluar señales de
  verdad -- no es un cuelgue, es esperado. Se ve en el log como
  `htf_warmup, klines=N`.
- La API queda en `http://<ip-del-vm>:8001` (`/health`, `/api/state/<user_id>`,
  WS en `/ws/<user_id>`) -- abrí el puerto en el firewall del VM si vas a
  conectar el dashboard desde afuera.
