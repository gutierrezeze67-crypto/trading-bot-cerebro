// PM2 config para BRAIN (unified_brain.main_orchestrator) -- el motor que
// ejecuta ordenes reales en MT5. Los demas procesos de la plataforma
// (SCALP/SWING/zone readers/dashboard) no estan aca a proposito: este
// paquete es "el cerebro", no la plataforma completa - ver DEPLOY.md.
//
// Uso: pm2 start ecosystem.config.js   (correr desde ~/platform)
module.exports = {
  apps: [
    {
      name: "brain",
      script: "main_orchestrator.py",
      interpreter: "./.venv/bin/python",   // Windows: ".venv/Scripts/python.exe"
      cwd: "./unified_brain",
      autorestart: true,
      max_restarts: 10,
      restart_delay: 5000,
      out_file: "../logs/brain-out.log",
      error_file: "../logs/brain-error.log",
      time: true,
    },
  ],
};
